# WEBSITE — Nude Minimalist School Project

A responsive one-page website made with HTML, CSS, and JavaScript, prepared for automatic deployment to GitHub Pages.

## Files
- `index.html` — page content and sections
- `style.css` — design and responsive layout
- `script.js` — mobile menu, navigation highlighting, and demo contact form
- `.github/workflows/pages.yml` — automatically deploys the site to GitHub Pages when you push to `main`

## Publish it using GitHub Pages

1. Sign in to GitHub and create a **new repository**. A suggested name is `nude-minimalist-website`.
2. Upload all files and folders from this project. Make sure `index.html`, `style.css`, `script.js`, and the `.github/workflows/pages.yml` file are included.
3. Commit the files to the `main` branch.
4. In the repository, open **Settings → Pages**.
5. Under **Build and deployment**, select **GitHub Actions** as the source if it is not already selected.
6. Open the **Actions** tab and wait for **Deploy website to GitHub Pages** to finish successfully.
7. Return to **Settings → Pages** to find the published website URL. It usually looks like `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

After setup, every push to the `main` branch triggers a new deployment.

## Optional: upload with Git
If you use Git locally, open a terminal in this folder and run:

```bash
git init
git add .
git commit -m "Create nude minimalist website"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the example remote URL with your actual repository URL. If Git says the remote already exists, use `git remote set-url origin YOUR-REPOSITORY-URL`.

## Important
The contact form is front-end only: it validates entries and shows a demo confirmation, but does not send email or save messages. The sample email and location should be changed to your real contact information before publishing.
